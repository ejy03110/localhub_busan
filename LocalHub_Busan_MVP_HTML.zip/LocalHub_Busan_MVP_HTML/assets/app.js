
/*
==========================================================
게시판 기본 샘플 데이터

게시글은 두 단계로 분류합니다.

1. topic: 게시글의 큰 주제
   - 관광
   - 숙박
   - 기타
   - 자유

2. postType: 선택한 주제 안에서 글의 성격
   - 질문
   - 후기
   - 자유

기본 비밀번호는 교육용 테스트를 위해 1234로 설정합니다.
==========================================================
*/

// 챗봇 검색 결과를 저장하는 전역 변수
let chatbotSearchResults = [];

const SAMPLE_POSTS = [
  {
    id: 6,
    title: "해운대 근처 가족 호텔 추천 부탁드립니다",
    content: "아이와 함께 묵기 좋은 해운대 근처 숙소를 찾고 있습니다.",
    password: "1234",
    createdAt: "2026-07-14",
    topic: "숙박",
    postType: "질문"
  },
  {
    id: 5,
    title: "광안리 숙소 1박 후기",
    content: "광안리 바다 근처 숙소를 이용했는데 야경을 보기 좋았습니다.",
    password: "1234",
    createdAt: "2026-07-13",
    topic: "숙박",
    postType: "후기"
  },
  {
    id: 4,
    title: "비 오는 날 갈 만한 부산 관광지 있나요?",
    content: "실내에서 이용할 수 있는 부산 관광지를 추천받고 싶습니다.",
    password: "1234",
    createdAt: "2026-07-12",
    topic: "관광",
    postType: "질문"
  },
  {
    id: 3,
    title: "감천문화마을 방문 후기",
    content: "골목과 전망이 아름다웠지만 경사가 많아서 편한 신발이 필요합니다.",
    password: "1234",
    createdAt: "2026-07-11",
    topic: "관광",
    postType: "후기"
  },
  {
    id: 2,
    title: "부산 여행 준비하면서 궁금한 점",
    content: "부산 대중교통 이용 팁을 자유롭게 공유해주세요.",
    password: "1234",
    createdAt: "2026-07-10",
    topic: "기타",
    postType: "자유"
  },
  {
    id: 1,
    title: "부산 여행 자유 이야기",
    content: "부산에서 좋았던 장소를 자유롭게 이야기해 주세요.",
    password: "1234",
    createdAt: "2026-07-09",
    topic: "자유",
    postType: "자유"
  }
];

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  })[ch]);
}

/*
==========================================================
localStorage에서 게시글 목록을 가져오는 함수

기존 게시글은 category 속성만 가지고 있을 수 있습니다.
새 게시글은 topic과 postType을 사용하므로,
오래된 데이터를 자동으로 새 구조로 변환합니다.
==========================================================

*/
function getPosts() {
  /*
    localStorage에서 게시글 문자열을 가져옵니다.
  */
  const raw = localStorage.getItem("localhub-mvp-posts");

  /*
    저장된 게시글이 하나도 없다면
    SAMPLE_POSTS를 localStorage에 저장하고 반환합니다.
  */
  if (!raw) {
    localStorage.setItem(
      "localhub-mvp-posts",
      JSON.stringify(SAMPLE_POSTS)
    );

    return [...SAMPLE_POSTS];
  }

  try {
    /*
      JSON 문자열을 실제 JavaScript 배열로 바꿉니다.
    */
    const posts = JSON.parse(raw);

    /*
      예전 게시글 데이터는 category만 가지고 있을 수 있습니다.

      예전 구조:
      {
        category: "관광지"
      }

      새 구조:
      {
        topic: "관광",
        postType: "자유"
      }
    */
    const convertedPosts = posts.map(post => {
      /*
        이미 topic과 postType이 있다면
        새 구조의 게시글이므로 그대로 반환합니다.
      */
      if (post.topic && post.postType) {
        return post;
      }

      /*
        기존 카테고리를 새 주제로 바꾸기 위한 기본값입니다.
      */
      let convertedTopic = "기타";

      /*
        관광지, 문화시설, 여행코스는
        새 구조에서 관광 주제로 합칩니다.
      */
      if (
        post.category === "관광지" ||
        post.category === "문화시설" ||
        post.category === "여행코스"
      ) {
        convertedTopic = "관광";
      }

      /*
        기존 데이터에 숙박 또는 맛집이 있다면
        임시로 숙박 주제로 변환합니다.

        음식점 JSON은 사용하지 않지만,
        예전 localStorage에 맛집 게시글이 남아 있을 수 있어
        오류 방지를 위해 포함합니다.
      */
      if (
        post.category === "숙박" ||
        post.category === "맛집"
      ) {
        convertedTopic = "숙박";
      }

      /*
        기존 데이터에는 글 성격 정보가 없으므로
        기본 글 성격을 자유로 설정합니다.
      */
      return {
        ...post,
        topic: convertedTopic,
        postType: "자유"
      };
    });

    /*
      변환된 데이터를 다시 저장해서
      다음부터는 새 구조를 그대로 사용합니다.
    */
    savePosts(convertedPosts);

    return convertedPosts;
  } catch (error) {
    /*
      localStorage 데이터가 손상되어 JSON 변환이 실패하면
      오류를 콘솔에 출력하고 샘플 데이터를 사용합니다.
    */
    console.error(
      "게시글 데이터를 불러오지 못했습니다.",
      error
    );

    return [...SAMPLE_POSTS];
  }
}

function savePosts(posts) {
  localStorage.setItem("localhub-mvp-posts", JSON.stringify(posts));
}

function getId() {
  return Number(new URLSearchParams(location.search).get("id"));
}

// ===== 챗봇 검색 결과 저장/로드 함수 =====
function saveChatbotSearchResults(places) {
  localStorage.setItem("chatbotSearchResults", JSON.stringify(places));
}

function getChatbotSearchResults() {
  try {
    return JSON.parse(localStorage.getItem("chatbotSearchResults") || "[]");
  } catch {
    return [];
  }
}

function clearChatbotSearchResults() {
  localStorage.removeItem("chatbotSearchResults");
}

// ===== 챗봇 JSON 데이터 검색 =====
let cachedPlacesData = null; // 로드된 데이터 캐싱

// 모든 JSON 파일 로드 (한 번만 로드)
async function loadPlacesData() {
  if (cachedPlacesData) return cachedPlacesData;

  const files = {
    "관광지": "data/부산_관광지.json",
    "문화시설": "data/부산_문화시설.json",
    "축제·행사": "data/부산_축제공연행사.json",
    "레포츠": "data/부산_레포츠.json",
    "쇼핑": "data/부산_쇼핑.json",
    "숙박": "data/부산_숙박.json"
  };

  const data = {};
  try {
    for (const [category, path] of Object.entries(files)) {
      const response = await fetch(path);
      const json = await response.json();
      data[category] = (json.items || []).slice(0, 100); // 성능상 100개만
    }
    cachedPlacesData = data;
    return data;
  } catch (error) {
    console.error("JSON 로딩 오류:", error);
    return data;
  }
}

// 사용자 입력에서 카테고리 감지
function detectCategory(text) {
  const categoryKeywords = {
    "관광지": ["관광지", "여행", "명소", "볼거리", "경치", "경관"],
    "축제·행사": ["축제", "행사", "공연", "이벤트", "콘서트", "전시"],
    "문화시설": ["문화시설", "박물관", "미술관", "전시", "갤러리", "극장"],
    "레포츠": ["레포츠", "운동", "스포츠", "마라톤", "서핑", "골프"],
    "쇼핑": ["쇼핑", "쇼핑몰", "백화점", "마켓", "시장", "음식"],
    "숙박": ["숙박", "호텔", "펜션", "에어비앤비", "숙소", "묵을", "묵을"]
  };

  const lowerText = text.toLowerCase();
  for (const [category, keywords] of Object.entries(categoryKeywords)) {
    if (keywords.some(kw => lowerText.includes(kw))) {
      return category;
    }
  }
  return null;
}

// 장소 검색 (카테고리 + 키워드)
// 장소 검색 (카테고리 + 키워드) - 랜덤 5개 반환
async function searchPlaces(category, keyword) {
  const data = await loadPlacesData();
  let places = data[category] || [];

  // 카테고리명 자체로 검색하면 필터링 안 함 (전체 반환)
  const categoryNames = Object.keys(data);
  const isJustCategory = categoryNames.includes(keyword.trim());

  if (keyword && !isJustCategory) {
    places = places.filter(place =>
      place.title.toLowerCase().includes(keyword.toLowerCase()) ||
      place.addr1.toLowerCase().includes(keyword.toLowerCase())
    );
  }

  // Fisher-Yates 셔플 알고리즘 (랜덤화)
  const shuffle = (arr) => {
    const shuffled = [...arr];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  };

  const shuffled = shuffle(places);
  return shuffled.slice(0, 5); // 랜덤 5개 반환
}

// 장소 정보를 보기 좋은 형식으로 포맷
function formatPlaceInfo(place) {
  const tel = place.tel ? `📞 ${place.tel}\n` : "";
  const addr = place.addr1 ? `📍 ${place.addr1}` : "";
  return `🏢 <strong>${escapeHtml(place.title)}</strong>\n${tel}${addr}`;
}

// 장소명으로 게시글 검색 (3개까지)
function searchPostsByPlace(placeName) {
  const posts = getPosts();
  const lowerPlace = placeName.toLowerCase().replace(/\s+/g, "");
  
  return posts
    .filter(post => {
      const titleMatch = post.title.toLowerCase().replace(/\s+/g, "").includes(lowerPlace);
      const contentMatch = post.content.toLowerCase().includes(placeName.toLowerCase());
      return titleMatch || contentMatch;
    })
    .slice(0, 3); // 최대 3개
}

function initChat() {
  const toggles = document.querySelectorAll("[data-chat-toggle]");
  const panel = document.querySelector("[data-chat-panel]");
  const close = document.querySelector("[data-chat-close]");
  const form = document.querySelector("[data-chat-form]");
  const input = document.querySelector("[data-chat-input]");
  const body = document.querySelector("[data-chat-body]");

  if (!panel) return;

  const toggle = () => panel.classList.toggle("open");
  toggles.forEach(btn => btn.addEventListener("click", toggle));
  close?.addEventListener("click", toggle);

  form?.addEventListener("submit", event => {
    event.preventDefault();
    const text = input.value.trim();
    if (!text) return;

    body.insertAdjacentHTML("beforeend", `<div class="message user">${escapeHtml(text)}</div>`);
    input.value = "";

      setTimeout(async () => {
  let answer = "부산 지역 관광지, 축제·행사, 문화시설, 레포츠, 쇼핑, 숙박을 질문해 주세요.";
  
  const category = detectCategory(text);
if (category) {
  // 카테고리명 제거 후 의미있는 키워드만 추출 (길이 3 이상)
  const remaining = text.replace(category, "").trim();
  const keyword = remaining.split(/\s+/).filter(w => w.length >= 3).join(" ");
  const places = await searchPlaces(category, keyword);
  console.log("검색:", {category, keyword, places: places.length}); // 디버깅용
    saveChatbotSearchResults(places);
    chatbotSearchResults = places;
        if (places.length > 0) {
  const placeList = await Promise.all(places.map(async p => {
    const relatedPosts = searchPostsByPlace(p.title);
    let placeHtml = `🏢 <strong>${escapeHtml(p.title)}</strong>`;
    
    if (p.tel) placeHtml += `<br>📞 ${escapeHtml(p.tel)}`;
    if (p.addr1) placeHtml += `<br>📍 ${escapeHtml(p.addr1)}`;
    
    // 관련 게시글 추가
    if (relatedPosts.length > 0) {
      placeHtml += `<div class="related-posts">💬 이 장소 후기:`;
      relatedPosts.forEach(post => {
        placeHtml += `<br><a href="post-detail.html?id=${post.id}" class="post-link">· ${escapeHtml(post.title)}</a>`;
      });
      placeHtml += `</div>`;
    }
    
    return placeHtml;
  }));
  
  answer = `🔍 <strong>${text}</strong> 검색 결과:<br><br>${placeList.join("<br><br>")}`;
} else {
  answer = `죄송합니다. "${text}" 검색 결과가 없습니다. 다른 키워드를 시도해 보세요.`;
}
  } else if (text.includes("게시글")) {
    answer = "커뮤니티 게시판에서 제목 검색을 지원합니다.";
  }

  body.insertAdjacentHTML("beforeend", `<div class="message bot">${answer}</div>`);
  body.scrollTop = body.scrollHeight;
}, 400);
  });
}

function renderRecent() {
  const target = document.querySelector("[data-recent-posts]");

  if (!target) return;

  const posts = getPosts()
    .slice()
    .sort((a, b) => b.id - a.id)
    .slice(0, 3);

  target.innerHTML = posts
    .map((post, index) => {
      const images = [
        "assets/hero-busan.jpg",
        "assets/hero-busan.jpg",
        "assets/hero-busan.jpg"
      ];

      return `
        <a
          class="community-card"
          href="post-detail.html?id=${post.id}"
        >
          <div class="community-card-content">
            <span class="community-category">
              ${escapeHtml(post.postType || post.topic || "기타")}
            </span>

            <h3>
              ${escapeHtml(post.title)}
            </h3>

            <p>
              ${escapeHtml(post.content)}
            </p>

            <div class="community-meta">
              <span>♡ ${23 - index * 5}</span>
              <span>◎ ${145 - index * 28}</span>
              <span>${post.createdAt}</span>
            </div>
          </div>

          <div
            class="community-thumb"
            style="background-image:url('${images[index]}')"
          ></div>
        </a>
      `;
    })
    .join("");
}

function initMobileMenu() {
  const menuButton = document.querySelector(".mobile-nav-button");
  const mainNav = document.querySelector(".main-nav");

  if (!menuButton || !mainNav) return;

  menuButton.addEventListener("click", () => {
    mainNav.classList.toggle("open");

    const isOpen = mainNav.classList.contains("open");
    menuButton.setAttribute("aria-expanded", String(isOpen));
  });
}

// =========================================================
// 메인 화면 통계 카드에 실제 JSON 개수를 표시
// =========================================================
async function renderStatistics() {

  const files = [
    ["관광지", "data/부산_관광지.json"],
    ["문화시설", "data/부산_문화시설.json"],
    ["숙박", "data/부산_숙박.json"],
    ["쇼핑", "data/부산_쇼핑.json"]
  ];

  for (const [name, path] of files) {

    try {
      const response = await fetch(path);
      const data = await response.json();

      const target = document.querySelector(`[data-stat="${name}"]`);

      if (target) {
        target.textContent = (data.items || []).length;
      }

    } catch (error) {
      console.error(`${name} 데이터 로딩 실패`, error);
    }
  }
}

async function renderFeaturedPlaces() {
  const target = document.querySelector("[data-featured-places]");

  if (!target) return;

  try {
    const response = await fetch("data/부산_관광지.json");

    if (!response.ok) {
      throw new Error("추천 관광지 데이터를 불러오지 못했습니다.");
    }

    const data = await response.json();

    const places = (data.items || [])
      .filter(place => place.firstimage || place.firstimage2)
      .sort(() => Math.random() - 0.5)
      .slice(0, 4);

    target.innerHTML = places.map(place => {
      const image =
        place.firstimage2 ||
        place.firstimage ||
        "assets/hero-busan.jpg";

      const address = [place.addr1, place.addr2]
        .filter(Boolean)
        .join(" ");

      return `
        <article class="place-card">
          <div
            class="place-image"
            style="background-image: url('${escapeHtml(image)}')"
          ></div>

          <div class="place-content">
            <span class="badge">관광지</span>

            <h3>${escapeHtml(place.title || "장소명 없음")}</h3>

            <p>
              ${escapeHtml(address || "주소 정보 없음")}
            </p>

            ${
              place.mapx && place.mapy
                ? `
                  <a
                    href="https://map.kakao.com/link/map/${encodeURIComponent(
                      place.title || "부산 장소"
                    )},${place.mapy},${place.mapx}"
                    target="_blank"
                    rel="noopener"
                  >
                    📍 지도 보기
                  </a>
                `
                : ""
            }
          </div>
        </article>
      `;
    }).join("");
  } catch (error) {
    console.error(error);

    target.innerHTML = `
      <p class="notice">
        추천 관광지를 불러오지 못했습니다.
      </p>
    `;
  }
}

// =========================================================
// 부산 현재 날씨 표시
// Open-Meteo API 사용
// =========================================================
async function renderWeather() {
  const temperatureTarget = document.querySelector(
    "[data-weather-temperature]"
  );

  const descriptionTarget = document.querySelector(
    "[data-weather-description]"
  );

  const rainTarget = document.querySelector(
    "[data-weather-rain]"
  );

  const windTarget = document.querySelector(
    "[data-weather-wind]"
  );

  const highTarget = document.querySelector(
    "[data-weather-high]"
  );

  const lowTarget = document.querySelector(
    "[data-weather-low]"
  );

  // 날씨 카드가 없는 페이지에서는 실행하지 않습니다.
  if (!temperatureTarget) return;

  const iconTarget = document.querySelector(
    "[data-weather-icon]"
  );  

  const latitude = 35.1796;
  const longitude = 129.0756;

  const url =
    "https://api.open-meteo.com/v1/forecast" +
    `?latitude=${latitude}` +
    `&longitude=${longitude}` +
    "&current=temperature_2m,precipitation,weather_code,wind_speed_10m"
    + "&daily=temperature_2m_max,temperature_2m_min"
    "&timezone=Asia%2FSeoul";

  try {
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error("날씨 정보를 불러오지 못했습니다.");
    }

    const data = await response.json();
    const current = data.current;

    temperatureTarget.textContent =
      `${Math.round(current.temperature_2m)}°`;

    descriptionTarget.textContent =
      getWeatherDescription(current.weather_code);

    iconTarget.textContent = 
    getWeatherIcon(current.weather_code);

    rainTarget.textContent =
      `🌧️강수 ${current.precipitation}mm`;

    windTarget.textContent =
      `💨바람 ${current.wind_speed_10m}km/h`;

    highTarget.textContent =
      `🔥최고: ${Math.round(data.daily.temperature_2m_max[0])}°`;

    lowTarget.textContent =
      `❄️최저: ${Math.round(data.daily.temperature_2m_min[0])}°`;

  } catch (error) {
    console.error("날씨 데이터 로딩 실패:", error);

    descriptionTarget.textContent =
      "현재 날씨를 불러오지 못했습니다.";

    rainTarget.textContent = "강수 정보 없음";
    windTarget.textContent = "바람 정보 없음";
  }
}
// Open-Meteo 날씨 코드를 한국어 설명으로 변환합니다.
function getWeatherDescription(code) {
  if (code === 0) return "맑음";

  if (code === 1) return "대체로 맑음";

  if (code === 2) return "부분적으로 흐림";

  if (code === 3) return "흐림";

  if (code === 45 || code === 48) {
    return "안개";
  }

  if ([51, 53, 55, 56, 57].includes(code)) {
    return "이슬비";
  }

  if ([61, 63, 65, 66, 67].includes(code)) {
    return "비";
  }

  if ([71, 73, 75, 77].includes(code)) {
    return "눈";
  }

  if ([80, 81, 82].includes(code)) {
    return "소나기";
  }

  if ([85, 86].includes(code)) {
    return "눈 소나기";
  }

  if ([95, 96, 99].includes(code)) {
    return "뇌우";
  }

  return "날씨 정보 확인 중";
}

// 날씨 코드에 따라 아이콘을 반환합니다.
function getWeatherIcon(code) {
  if (code === 0) return "☀️";

  if (code === 1 || code === 2) {
    return "🌤️";
  }

  if (code === 3) {
    return "☁️";
  }

  if (code === 45 || code === 48) {
    return "🌫️";
  }

  if (
    [51, 53, 55, 56, 57].includes(code)
  ) {
    return "🌦️";
  }

  if (
    [61, 63, 65, 66, 67, 80, 81, 82].includes(code)
  ) {
    return "🌧️";
  }

  if (
    [71, 73, 75, 77, 85, 86].includes(code)
  ) {
    return "❄️";
  }

  if (
    [95, 96, 99].includes(code)
  ) {
    return "⛈️";
  }

  return "🌤️";
}

/*
==========================================================
게시판 목록 출력 및 검색 기능

검색 기준
1. 제목 검색
2. 주제 필터: 관광 / 숙박 / 기타 / 자유
3. 글 성격 필터: 질문 / 후기 / 자유

board.html의 다음 요소와 연결됩니다.

data-board-body
data-board-search
data-board-topic
data-board-post-type
data-board-search-button
==========================================================
*/
function initBoard() {
  /*
    게시글 목록이 들어갈 tbody 요소입니다.
  */
  const body = document.querySelector(
    "[data-board-body]"
  );

  /*
    게시글 제목 검색 입력창입니다.
  */
  const search = document.querySelector(
    "[data-board-search]"
  );

  /*
    게시글의 큰 분류인 주제 선택창입니다.

    관광 / 숙박 / 기타 / 자유
  */
  const topicSelect = document.querySelector(
    "[data-board-topic]"
  );

  /*
    선택한 주제 안에서 글의 성격을 구분하는 선택창입니다.

    질문 / 후기 / 자유
  */
  const postTypeSelect = document.querySelector(
    "[data-board-post-type]"
  );

  /*
    검색 조건을 적용하는 버튼입니다.
  */
  const button = document.querySelector(
    "[data-board-search-button]"
  );

  /*
    현재 페이지에 게시글 목록 영역이 없다면
    이 함수를 더 이상 실행하지 않습니다.

    app.js는 여러 HTML에서 함께 사용하기 때문에
    해당 요소가 없는 페이지에서는 안전하게 종료해야 합니다.
  */
  if (!body) return;

  /*
    현재 검색 조건에 맞는 게시글을 찾아
    게시판 표에 출력하는 함수입니다.
  */
  const draw = () => {
    /*
      제목 검색어를 읽습니다.

      검색창이 없을 가능성까지 고려해
      optional chaining과 기본값을 사용합니다.
    */
    const keyword = (
      search?.value || ""
    )
      .trim()
      .toLowerCase();

    /*
      선택된 주제를 가져옵니다.

      빈 값이면 전체 주제를 뜻합니다.
    */
    const selectedTopic =
      topicSelect?.value || "";

    /*
      선택된 글 성격을 가져옵니다.

      빈 값이면 전체 글 성격을 뜻합니다.
    */
    const selectedPostType =
      postTypeSelect?.value || "";

    /*
      localStorage에서 게시글을 불러옵니다.
    */
    const posts = getPosts()
      .slice()

      /*
        게시글 ID가 큰 최신 글이 위로 오도록 정렬합니다.
      */
      .sort((a, b) => b.id - a.id)

      /*
        제목, 주제, 글 성격 조건을 모두 검사합니다.
      */
      .filter(post => {
        /*
          검색어가 없거나,
          게시글 제목에 검색어가 포함되면 통과합니다.
        */
        const matchesKeyword =
          !keyword ||
          post.title
            .toLowerCase()
            .includes(keyword);

        /*
          주제가 선택되지 않았거나,
          게시글 주제가 선택한 값과 같으면 통과합니다.
        */
        const matchesTopic =
          !selectedTopic ||
          post.topic === selectedTopic;

        /*
          글 성격이 선택되지 않았거나,
          게시글 성격이 선택한 값과 같으면 통과합니다.
        */
        const matchesPostType =
          !selectedPostType ||
          post.postType === selectedPostType;

        return (
          matchesKeyword &&
          matchesTopic &&
          matchesPostType
        );
      });

    /*
      검색 결과가 있으면 게시글 행을 출력하고,
      없으면 검색 결과가 없다는 문구를 출력합니다.
    */
    body.innerHTML = posts.length
      ? posts.map(post => `
          <tr>
            <!-- 게시글 번호 -->
            <td class="number-col">
              ${post.id}
            </td>

            <!-- 게시글의 큰 주제 -->
            <td>
              ${escapeHtml(post.topic || "기타")}
            </td>

            <!-- 주제 안에서의 글 성격 -->
            <td>
              ${escapeHtml(post.postType || "자유")}
            </td>

            <!-- 게시글 제목과 상세 페이지 링크 -->
            <td>
              <a
                class="post-title"
                href="post-detail.html?id=${post.id}"
              >
                ${escapeHtml(post.title)}
              </a>
            </td>

            <!-- 게시글 작성일 -->
            <td class="date-col">
              ${post.createdAt}
            </td>
          </tr>
        `).join("")
      : `
          <tr>
            <td colspan="5">
              검색 결과가 없습니다.
            </td>
          </tr>
        `;
  };

  /*
    게시판 페이지를 처음 열었을 때
    전체 게시글을 한 번 출력합니다.
  */
  draw();

  /*
    검색 버튼 클릭 시 필터를 적용합니다.
  */
  button?.addEventListener(
    "click",
    draw
  );

  /*
    주제를 변경하면 바로 결과를 다시 출력합니다.
  */
  topicSelect?.addEventListener(
    "change",
    draw
  );

  /*
    글 성격을 변경하면 바로 결과를 다시 출력합니다.
  */
  postTypeSelect?.addEventListener(
    "change",
    draw
  );

  /*
    제목 검색창에서 Enter 키를 눌러도
    검색 버튼과 동일하게 작동합니다.
  */
  search?.addEventListener(
    "keydown",
    event => {
      if (event.key === "Enter") {
        draw();
      }
    }
  );
}

function initDetail() {
  /*
    게시글 상세 화면에 제목, 내용, 분류 정보, 작성일을 출력하는 함수입니다.

    [연결되는 HTML 요소]
    - data-detail-title
    - data-detail-content
    - data-detail-meta

    [기능]
    1. URL의 id로 게시글을 찾습니다.
    2. 게시글이 없으면 안내 후 board.html로 이동합니다.
    3. 제목과 내용을 화면에 출력합니다.
    4. topic과 postType을 기준으로 분류 정보를 표시합니다.
    5. 수정과 삭제 버튼 이벤트를 연결합니다.
  */
  const title = document.querySelector("[data-detail-title]");
  const content = document.querySelector("[data-detail-content]");
  const meta = document.querySelector("[data-detail-meta]");

  if (!title || !content || !meta) return;

  const posts = getPosts();
  const requestedId = getId();
  const post = posts.find(item => item.id === requestedId);

  if (!post) {
    alert("게시글을 찾을 수 없습니다.");
    location.href = "board.html";
    return;
  }

  title.textContent = post.title;
  content.textContent = post.content;
  meta.textContent = `${post.topic || "기타"} · ${post.postType || "자유"} · 작성일 ${post.createdAt}`;

  document.querySelector("[data-edit]")?.addEventListener("click", () => openPassword("edit", post));
  document.querySelector("[data-delete]")?.addEventListener("click", () => openPassword("delete", post));
}

function openPassword(mode, post) {
  const backdrop = document.querySelector("[data-password-modal]");
  const input = document.querySelector("[data-password-input]");
  const title = document.querySelector("[data-password-modal-title]");
  const confirm = document.querySelector("[data-password-confirm]");
  const cancel = document.querySelector("[data-password-cancel]");

  title.textContent = mode === "edit" ? "수정 비밀번호 확인" : "삭제 비밀번호 확인";
  input.value = "";
  backdrop.classList.add("open");
  input.focus();

  const close = () => backdrop.classList.remove("open");
  cancel.onclick = close;
  backdrop.onclick = e => { if (e.target === backdrop) close(); };

  confirm.onclick = () => {
    if (input.value !== post.password) {
      alert("비밀번호가 일치하지 않습니다.");
      return;
    }
    if (mode === "edit") {
      location.href = `post-write.html?id=${post.id}`;
      return;
    }
    savePosts(getPosts().filter(item => item.id !== post.id));
    alert("게시글이 삭제되었습니다.");
    location.href = "board.html";
  };
}

/*
==========================================================
게시글 작성 및 수정 기능

[이 함수가 담당하는 기능]

1. 새 게시글 작성
2. 기존 게시글 수정
3. 주제 저장
   - 관광
   - 숙박
   - 기타
   - 자유
4. 글 성격 저장
   - 질문
   - 후기
   - 자유
5. 제목, 내용, 비밀번호 검사
6. localStorage에 게시글 저장
7. 저장 후 게시판 목록으로 이동

[작성 모드와 수정 모드 구분]

post-write.html
→ 새 게시글 작성

post-write.html?id=3
→ ID가 3인 게시글 수정
==========================================================
*/
function initWrite() {
  /*
    게시글 작성 폼을 찾습니다.

    post-write.html에 있는
    data-post-form 속성과 연결됩니다.
  */
  const form = document.querySelector(
    "[data-post-form]"
  );

  /*
    현재 페이지에 게시글 작성 폼이 없다면
    이 함수를 실행하지 않고 종료합니다.

    app.js는 여러 HTML 페이지에서 함께 사용하기 때문에
    이러한 확인 과정이 필요합니다.
  */
  if (!form) return;


  /*
    주소에 포함된 게시글 ID를 가져옵니다.

    예:
    post-write.html?id=3

    위 주소에서는 id 값이 3이 됩니다.

    ID가 있으면 수정 모드,
    ID가 없으면 새 글 작성 모드입니다.
  */
  const id = getId();


  /*
    게시글 입력 요소를 각각 찾습니다.
  */

  // 게시글 주제 선택창
  const topic = document.querySelector(
    "[data-post-topic]"
  );

  // 글 성격 선택창
  const postType = document.querySelector(
    "[data-post-type]"
  );

  // 제목 입력창
  const title = document.querySelector(
    "[data-post-title]"
  );

  // 내용 입력창
  const content = document.querySelector(
    "[data-post-content]"
  );

  // 수정·삭제용 비밀번호 입력창
  const password = document.querySelector(
    "[data-post-password]"
  );

  // 페이지 제목: 게시글 작성 또는 게시글 수정
  const heading = document.querySelector(
    "[data-form-title]"
  );


  /*
    수정 모드 처리

    주소에 게시글 ID가 있다면
    기존 게시글을 찾아 입력창에 내용을 채웁니다.
  */
  if (id) {
    const post = getPosts().find(
      item => item.id === id
    );

    /*
      해당 ID의 게시글을 찾은 경우에만
      수정 화면을 구성합니다.
    */
    if (post) {
      heading.textContent = "게시글 수정";

      /*
        기존 게시글 값을 각 입력창에 넣습니다.
      */
      topic.value = post.topic;
      postType.value = post.postType;
      title.value = post.title;
      content.value = post.content;
      password.value = post.password;
    } else {
      /*
        존재하지 않는 게시글 ID로 접근한 경우
        안내 후 게시판 목록으로 이동합니다.
      */
      alert("수정할 게시글을 찾을 수 없습니다.");
      location.href = "board.html";
      return;
    }
  }


  /*
    저장 버튼을 누르면 form의 submit 이벤트가 발생합니다.
  */
  form.addEventListener("submit", event => {
    /*
      HTML 폼의 기본 제출 동작을 막습니다.

      이 코드가 없으면 페이지가 새로고침되면서
      JavaScript 저장 처리가 중단될 수 있습니다.
    */
    event.preventDefault();


    /*
      사용자가 입력한 값을 하나의 객체로 정리합니다.

      게시글의 큰 분류인 topic을 먼저 작성하고,
      그 안의 글 성격인 postType을 다음에 작성합니다.
    */
    const values = {
      topic: topic.value,
      postType: postType.value,
      title: title.value.trim(),
      content: content.value.trim(),
      password: password.value.trim()
    };


    /*
      입력값 검사

      제목과 내용은 반드시 입력해야 하며,
      비밀번호는 4자리 이상이어야 합니다.
    */
    if (!values.title) {
      alert("제목을 입력하세요.");
      title.focus();
      return;
    }

    if (!values.content) {
      alert("내용을 입력하세요.");
      content.focus();
      return;
    }

    if (values.password.length < 4) {
      alert("비밀번호는 4자리 이상 입력하세요.");
      password.focus();
      return;
    }


    /*
      현재 저장된 게시글 목록을 불러옵니다.
    */
    const posts = getPosts();


    /*
      ID가 있으면 기존 게시글 수정,
      ID가 없으면 새 게시글 작성입니다.
    */
    if (id) {
      /*
        수정할 게시글의 배열 위치를 찾습니다.
      */
      const index = posts.findIndex(
        item => item.id === id
      );

      if (index === -1) {
        alert("수정할 게시글을 찾을 수 없습니다.");
        return;
      }

      /*
        기존 게시글의 ID와 작성일은 유지하면서
        사용자가 수정한 값만 덮어씁니다.
      */
      posts[index] = {
        ...posts[index],
        ...values
      };
    } else {
      /*
        새 게시글 ID 생성

        현재 가장 큰 ID에 1을 더합니다.
        게시글이 하나도 없다면 1부터 시작합니다.
      */
      const nextId = posts.length
        ? Math.max(...posts.map(post => post.id)) + 1
        : 1;

      /*
        새 게시글을 게시글 배열에 추가합니다.
      */
      posts.push({
        id: nextId,
        ...values,

        /*
          현재 날짜를 YYYY-MM-DD 형식으로 저장합니다.
        */
        createdAt: new Date()
          .toISOString()
          .slice(0, 10)
      });
    }


    /*
      변경된 게시글 목록을 localStorage에 저장합니다.
    */
    savePosts(posts);


    /*
      작성 또는 수정 완료 안내를 표시합니다.
    */
    alert(
      id
        ? "게시글이 수정되었습니다."
        : "게시글이 등록되었습니다."
    );


    /*
      저장이 완료되면 게시판 목록으로 이동합니다.
    */
    location.href = "board.html";
  });
}

function initMapFilters() {
  const checkboxes = document.querySelectorAll("[data-map-filter]");
  const info = document.querySelector("[data-map-info]");
  if (!checkboxes.length || !info) return;

  checkboxes.forEach(box => box.addEventListener("change", () => {
    const selected = [...checkboxes].filter(x => x.checked).map(x => x.value);
    info.textContent = selected.length ? `${selected.join(", ")} 카테고리를 지도에 표시 중입니다.` : "표시할 카테고리를 선택하세요.";
  }));
}

// 카테고리 매핑 (텍스트 → contenttypeid)
const CATEGORY_MAP = {
  "관광지": "12",
  "문화시설": "14",
  "축제": "15",
  "맛집": "39",
  "레포츠": "28",
  "쇼핑": "38",
  "숙박": "32"
};

// 부산 지도 초기화
let exploreMap = null;
let markers = [];

function initExploreMap() {
  if (exploreMap) return; // 이미 초기화됨
  
  // 부산 중심 좌표 (위도, 경도)
  const busanCenter = [35.1796, 129.0756];
  
  exploreMap = L.map('explore-map').setView(busanCenter, 12);
  
  // OpenStreetMap 타일 추가
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors',
    maxZoom: 19
  }).addTo(exploreMap);
}

function renderMapMarkers(places) {

  // 기존 마커 제거
  markers.forEach(marker => exploreMap.removeLayer(marker));
  markers = [];

  // 새 마커 추가
  places.forEach(place => {
    const lat = parseFloat(place.mapy);
    const lon = parseFloat(place.mapx);
    
    if (isNaN(lat) || isNaN(lon)) return; // 좌표 없으면 건너뛰기
    
    const marker = L.marker([lat, lon])
  .bindPopup(`
    <div style="font-size: 14px; width: 220px;">
      ${place.firstimage ? `<img src="${place.firstimage}" style="width:100%; height:120px; object-fit:cover; border-radius:8px; margin-bottom:8px;">` : '<div style="width:100%; height:120px; background:#e0e0e0; border-radius:8px; margin-bottom:8px; display:flex; align-items:center; justify-content:center; color:#999; font-size:12px;">이미지 없음</div>'}
      <strong>${escapeHtml(place.title)}</strong><br>
      <small>${escapeHtml(place.addr1)}</small>
      ${place.tel ? `<br><small style="color:#666;">☎ ${escapeHtml(place.tel)}</small>` : ''}
    </div>
  `)
  .addTo(exploreMap);
    
    markers.push(marker);
  });

  // 마커들이 보이도록 지도 줌 조정
  if (places.length > 0) {
    const group = new L.featureGroup(markers);
    exploreMap.fitBounds(group.getBounds().pad(0.1));
  }
}

// ===== EXPLORE 기능 =====
async function loadAllPlaces() {
  try {
    const files = [
      'data/부산_관광지.json',
      'data/부산_문화시설.json',
      'data/부산_레포츠.json',
      'data/부산_쇼핑.json',
      'data/부산_숙박.json',
      'data/부산_여행코스.json',
      'data/부산_축제공연행사.json'
    ];

    let allPlaces = [];
    for (const file of files) {
      const response = await fetch(file);
      const data = await response.json();
      allPlaces = allPlaces.concat(data.items);
    }
    return allPlaces;
  } catch (error) {
    console.error("JSON 로딩 오류:", error);
    return [];
  }
}


// 지역 매핑 (드롭다운 선택값 → 주소에서 찾을 구명)
const REGION_MAP = {
  "부산 전체": null,
  "서면구": "부산진구", 
  "수영구": "수영구",
  "해운대구": "해운대구",
  "영도구": "영도구"
};

// 주소에서 구(district) 추출
function extractDistrictFromAddr(addr1) {
  const match = addr1.match(/부산(?:광역시)?\s+(\S+구)/);
  return match ? match[1] : null;
}

async function initExplore() {
  const filterBtn = document.querySelector(".filter-panel .btn-primary");
  const checkboxes = document.querySelectorAll("[data-map-filter]");
  const searchInput = document.querySelector(".filter-panel .input");
  const regionSelect = document.querySelector(".filter-panel select");
  const mapInfo = document.querySelector("[data-map-info]");
  const resetBtn = document.getElementById("reset-filter");
  
  if (!filterBtn) return;
  
  // 지도 초기화
  if (!exploreMap) {
    initExploreMap();
  }
  
  // 챗봇 검색 결과 확인
  const chatResults = getChatbotSearchResults();
  if (chatResults.length > 0) {
    renderMapMarkers(chatResults);
    mapInfo.textContent = `챗봇 검색 결과: ${chatResults.length}개 장소`;
    clearChatbotSearchResults();
    return;  // ← 중요! 여기서 끝
  }
  
  // 초기 데이터 표시
  try {
    const allPlaces = await loadAllPlaces();
    if (allPlaces.length > 0) {
      renderMapMarkers(allPlaces);
    }
  } catch (e) {
    console.error("초기 지도 로딩 오류:", e);
  }
  
  // 필터링 함수 정의
  const applyFilter = async () => {
    const selectedCategories = [...checkboxes]
      .filter(cb => cb.checked)
      .map(cb => CATEGORY_MAP[cb.value]);

    const searchKeyword = searchInput.value.trim();
    const selectedRegion = regionSelect?.value;
    const targetDistrict = REGION_MAP[selectedRegion];
    
    const allPlaces = await loadAllPlaces();

    const filtered = allPlaces.filter(place => {
      const matchesCategory = selectedCategories.includes(place.contenttypeid);
      const matchesSearch = !searchKeyword || place.title.includes(searchKeyword);
      
      let matchesRegion = true;
      if (targetDistrict) {
        const district = extractDistrictFromAddr(place.addr1);
        matchesRegion = district === targetDistrict;
      }
      
      return matchesCategory && matchesSearch && matchesRegion;
    });

    if (!exploreMap) initExploreMap();
    renderMapMarkers(filtered);

    mapInfo.textContent = filtered.length 
      ? `${filtered.length}개의 장소를 찾았습니다.` 
      : "검색 결과가 없습니다.";
  };

  // 이벤트 연결
  filterBtn.addEventListener("click", applyFilter);

  searchInput.addEventListener("keydown", event => {
    if (event.key === "Enter") {
      event.preventDefault();
      applyFilter();
    }
  });

  regionSelect?.addEventListener("change", applyFilter);

  if (resetBtn) {
    resetBtn.addEventListener("click", async () => {
      checkboxes.forEach(cb => cb.checked = true);
      searchInput.value = "";
      regionSelect.value = "부산 전체";
      await applyFilter();
    });
  }
}


document.addEventListener("DOMContentLoaded", () => {
  initChat();
  renderRecent();
  renderFeaturedPlaces();
  renderStatistics();
  renderWeather();
  initBoard();
  initDetail();
  initWrite();
  initMapFilters();
  initExplore(); 
  initMobileMenu();
});
